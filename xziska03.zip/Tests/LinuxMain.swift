import XCTest

import proj1Tests

var tests = [XCTestCaseEntry]()
tests += proj1Tests.allTests()
XCTMain(tests)
